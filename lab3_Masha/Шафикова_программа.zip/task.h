#ifndef TASK_H
#define TASK_H

void show_number(int,int);
void draw_star(int, int, int, int);
void save();

#endif